#!/bin/sh
# We run the first part twice, since the first time it's going to output a bunch of maven log stuff.
mvn org.apache.maven.plugins:maven-help-plugin:2.1.1:evaluate -Dexpression=project.version | grep -v '\[' | grep -v 'Downloading:' | sed s/-SNAPSHOT//
export VERSION=`mvn org.apache.maven.plugins:maven-help-plugin:2.1.1:evaluate -Dexpression=project.version | grep -v '\[' | grep -v 'Downloading:' | sed s/-SNAPSHOT//`
git checkout development
git pull
git checkout -b release/$VERSION
git push --set-upstream origin release/$VERSION # Since development is a protected branch you need to log into github and issue a pull request for this.
mvn release:clean release:prepare # prepare release
# mvn release:perform

