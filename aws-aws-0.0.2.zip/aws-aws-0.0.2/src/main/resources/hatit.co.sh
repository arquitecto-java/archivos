#!/bin/bash

export HOME_TEMP=/tmp
echo --------------- HOME_TEMP=$HOME_TEMP



echo ---------------
echo ---------------
echo --------------- installing base packages
echo --------------- apt-get update
apt-get update
apt install unzip



echo ---------------
echo ---------------
echo --------------- cloning operations
echo --------------- cd $HOME_TEMP
cd $HOME_TEMP

echo --------------- git clone https://github.com/hatit/operations
git clone https://adrz1:tomas%40256@github.com/hatit/operations



echo ---------------
echo ---------------
echo --------------- installing and configuring apache2
echo --------------- apt-get install apache2 -y
apt-get install apache2 -y

echo --------------- cp $HOME_TEMP/operations/apache2/apache2.conf /etc/apache2/apache2.conf
cp $HOME_TEMP/operations/apache2/apache2.conf /etc/apache2/apache2.conf

echo --------------- cp $HOME_TEMP/operations/apache2/security.conf /etc/apache2/conf-enabled/security.conf
cp $HOME_TEMP/operations/apache2/security.conf /etc/apache2/conf-enabled/security.conf

echo --------------- cp $HOME_TEMP/operations/apache2/000-default.conf /etc/apache2/sites-enabled/000-default.conf
cp $HOME_TEMP/operations/apache2/000-default.conf /etc/apache2/sites-enabled/000-default.conf

echo --------------- a2enmod rewrite 
a2enmod rewrite

echo --------------- a2enmod headers
a2enmod headers

echo --------------- service apache2 restart
service apache2 restart



echo ---------------
echo ---------------
echo --------------- deploying hatit.co minimal
echo --------------- cloning hatit.co

echo --------------- git clone https://github.com/hatit/hatit.co
git clone https://adrz1:tomas%40256@github.com/hatit/hatit.co

echo --------------- cp -r $HOME_TEMP/hatit.co/* /var/www/html 
cp -r $HOME_TEMP/hatit.co/* /var/www/html 

echo --------------- mkdir /var/test
mkdir /var/test

echo --------------- mkdir /var/test/html
mkdir /var/test/html

echo --------------- cd $HOME_TEMP/hatit.co 
cd $HOME_TEMP/hatit.co 

echo --------------- git branch testing
git checkout testing

echo --------------- cp -r $HOME_TEMP/hatit.co/* /var/test/html 
cp -r $HOME_TEMP/hatit.co/* /var/test/html 



echo ---------------
echo ---------------
echo --------------- installing PHP7
echo --------------- apt-get install python-software-properties -y
apt-get install python-software-properties -y

echo --------------- LC_ALL=en_US.UTF-8 add-apt-repository ppa:ondrej/php -y 
LC_ALL=en_US.UTF-8 add-apt-repository ppa:ondrej/php -y

echo --------------- apt-get update -y 
apt-get update -y

echo --------------- apt-get install php7.0 -y 
apt-get install php7.0 -y

echo --------------- apt-get install php7.0-curl -y
apt-get install php7.0-curl -y

echo --------------- apt-get install php7.0-mysql -y
apt-get install php7.0-mysql -y

echo --------------- service apache2 restart
service apache2 restart



echo ---------------
echo ---------------
echo --------------- installing Wordpress
echo --------------- cd $HOME_TEMP
cd $HOME_TEMP

echo --------------- wget https://wordpress.org/latest.tar.gz
wget https://wordpress.org/latest.tar.gz

echo --------------- tar -xzvf latest.tar.gz 
tar -xzvf latest.tar.gz

echo --------------- cp -r $HOME_TEMP/wordpress/* /var/www/html/
cp -r $HOME_TEMP/wordpress/* /var/www/html/

echo --------------- chown -R www-data:www-data /var/www/html/*
chown -R www-data:www-data /var/www/html/*

echo --------------- cd $HOME_TEMP/operations 
cd $HOME_TEMP/operations

echo --------------- git checkout testing
git checkout development

echo --------------- cp $HOME_TEMP/operations/wordpress/wp-config.php /var/www/html/wp-config.php
cp $HOME_TEMP/operations/wordpress/wp-config.php /var/www/html/wp-config.php

echo --------------- cp -r $HOME_TEMP/wordpress/* /var/test/html/
cp -r $HOME_TEMP/wordpress/* /var/test/html/

echo --------------- chown -R www-data:www-data /var/test/html/*
chown -R www-data:www-data /var/test/html/*

echo --------------- cd $HOME_TEMP/operations 
cd $HOME_TEMP/operations

echo --------------- git checkout testing
git checkout testing

echo --------------- cp $HOME_TEMP/operations/wordpress/wp-config.php /var/test/html/wp-config.php
cp $HOME_TEMP/operations/wordpress/wp-config.php /var/test/html/wp-config.php



echo ---------------
echo ---------------
echo --------------- cloning hatit-blog
echo --------------- cd /var/www
cd /var/www/html

echo --------------- rm -rf index.html
rm -rf index.html

echo --------------- git init .
git init .

echo --------------- git remote add origin https://github.com/hatit/hatit-blog
git remote add origin https://adrz1:tomas%40256@github.com/hatit/hatit-blog

echo --------------- git pull origin development
git pull origin development

echo --------------- git checkout -f development
git checkout -f development

echo --------------- cd /var/test/html
cd /var/test/html

echo --------------- rm -rf index.html
rm -rf index.html

echo --------------- git init .
git init .

echo --------------- git remote add origin https://github.com/hatit/hatit-blog
git remote add origin https://adrz1:tomas%40256@github.com/hatit/hatit-blog

echo --------------- git pull origin testing
git pull origin testing

echo --------------- git checkout -f testing
git checkout -f testing



echo ---------------
echo ---------------
echo --------------- deploying php-services
echo --------------- cloning php-services
echo --------------- cd $HOME_TEMP
cd $HOME_TEMP

echo --------------- git clone https://github.com/hatit/php-services
git clone https://adrz1:tomas%40256@github.com/hatit/php-services

echo --------------- cd $HOME_TEMP/php-services
cd $HOME_TEMP/php-services

echo --------------- cp -r ./ /var/www/html/php-services/
cp -r ./ /var/www/html/php-services/

echo --------------- chown -R www-data:www-data /var/www/html/php-services/*
chown -R www-data:www-data /var/www/html/php-services/*

echo --------------- git checkout testing
git checkout testing

echo --------------- cp -r ./ /var/test/html/php-services/
cp -r ./ /var/test/html/php-services/

echo --------------- chown -R www-data:www-data /var/test/html/php-services/*
chown -R www-data:www-data /var/test/html/php-services/*


echo ---------------
echo ---------------
echo --------------- installing JDK ...
echo --------------- apt-get install default-jdk -y
apt-get install default-jdk -y



echo ---------------
echo ---------------
echo --------------- starting github webhooks
echo --------------- mkdir /var/log/github
mkdir /var/log/github

echo --------------- java -cp $HOME_TEMP/operations/github/github.jar co.hatit.github.GithubWebhooks
java -cp $HOME_TEMP/operations/github/github.jar co.hatit.github.GithubWebhooks > /var/log/github/webhook.log
