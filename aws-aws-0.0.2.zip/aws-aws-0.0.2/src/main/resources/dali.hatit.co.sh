#!/bin/bash

sudo su

export HOME_TEMP=/tmp

export user_github=samirllorente
export pass_github=Nathi1205

export dominio=dali.hatit.co
export versionPHP=php5
export repositorio=hatit/dalisaloom-blog/
export branch=2018-01/ThemeWordPress

export db_user=dali
export db_pass=dali_test
export db_host=34.231.235.4
export db_name=dali_test

echo "Actualizando el sistema"
apt-get update

echo "Instalando unzip"
apt-get install unzip

echo "Clonando repositorio operations"
cd  $HOME_TEMP
git clone https://$user_github:$pass_github@github.com/hatit/operations
cd 	$HOME_TEMP/operations
git checkout 2018-01/NuevosUsuarios

echo "Instalando apache"
apt-get install apache2 -y

echo "Remplazando informacion de dominio"
sed -i "s|hatit.co|$dominio|g" $HOME_TEMP/operations/apache2/apache2.conf
sed -i "s|hatit.co|$dominio|g" $HOME_TEMP/operations/apache2/000-default.conf

echo "Remplazando archivos en apache"
cp $HOME_TEMP/operations/apache2/apache2.conf /etc/apache2/apache2.conf
cp $HOME_TEMP/operations/apache2/security.conf /etc/apache2/conf-enabled/security.conf
cp $HOME_TEMP/operations/apache2/000-default.conf /etc/apache2/sites-enabled/000-default.conf

echo "Ensamblando rewrite"
a2enmod rewrite

echo "Ensamblando headers"
a2enmod headers

echo "Restaurando servicios de apache"
service apache2 restart

#echo "Instalando Python"
#apt-get install python-software-properties -y

echo "Preparando instalacion de PHP"
LC_ALL=en_US.UTF-8 add-apt-repository ppa:ondrej/php -y
apt-get update -y

if [ $versionPHP = "php5" ]; then 
    echo "Instalando PHP5"
	apt-get install php5.6 -y
	apt-get install php5.6-curl -y
	apt-get install php5.6-mysql -y	
else 
    echo "Instalando PH7"
	apt-get install php7.0 -y
	apt-get install php7.0-curl -y
	apt-get install php7.0-mysql -y
fi

echo "Restaurando servicios de apache"
service apache2 restart

echo "Descangando WordPress"
cd $HOME_TEMP
wget https://wordpress.org/latest.tar.gz

echo "Descomprimiendo WordPress" 
tar -xzvf latest.tar.gz

echo "Copiando archivos de WordPress a /var/www/html/"
cp -r $HOME_TEMP/wordpress/* /var/www/html/

echo "Copiando archivos de WordPress a /var/test/html/"
mkdir /var/test
mkdir /var/test/html
cp -r $HOME_TEMP/wordpress/* /var/test/html

echo "Modificando permisos a los archivos"
chown -R www-data:www-data /var/www/html/*

echo "Cambiando informacion de la base de datos" 
cp $HOME_TEMP/operations/wordpress/wp-config.php /var/www/html/wp-config.php
sed -i "s|BDUSERHATIT|$db_user|g"     /var/www/html/wp-config.php
sed -i "s|BDPASSWORDHATIT|$db_pass|g" /var/www/html/wp-config.php
sed -i "s|BDHOSTHATIT|$db_host|g" 	  /var/www/html/wp-config.php
sed -i "s|BDNAMEHATIT|$db_name|g"	  /var/www/html/wp-config.php

echo "Removiendo archivos molestos"
rm -rf /var/www/html/index.html
rm -R /var/www/html/wp-content/*
rm -R /var/test/html/wp-content/*

echo "Clonando repositorio $repositorio"
cd /var/www/html
git init .
git remote add origin https://$user_github:$pass_github@github.com/$repositorio
git pull origin $branch
git checkout -f $branch

echo "Clonando repositorio testing"
cd /var/test/html
git init .
git remote add origin https://$user_github:$pass_github@github.com/$repositorio
git pull origin testing
git checkout -f testing

echo  "Instalando SDK"
apt-get install default-jdk -y

echo "Listo!!"
mkdir /var/log/github
java -cp $HOME_TEMP/operations/github/github.jar co.hatit.github.GithubWebhooks > /var/log/github/webhook.log