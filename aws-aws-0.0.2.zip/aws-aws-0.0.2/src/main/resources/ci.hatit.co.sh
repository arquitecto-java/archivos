#!/bin/bash

export HOME_TEMP=/tmp
echo --------------- HOME_TEMP=$HOME_TEMP



echo ---------------
echo ---------------
echo --------------- installing base packages
echo --------------- apt-get update
apt-get update
apt install unzip

echo ---------------
echo ---------------
echo --------------- cloning operations
echo --------------- cd $HOME_TEMP
cd $HOME_TEMP

echo --------------- git clone https://github.com/hatit/operations
git clone https://adrz1:tomas%40256@github.com/hatit/operations



echo ---------------
echo ---------------
echo --------------- installing JDK
echo --------------- apt-get install default-jdk -y
apt-get install default-jdk -y



echo --------------- installing Wildfly
echo --------------- wget http://download.jboss.org/wildfly/10.1.0.Final/wildfly-10.1.0.Final.zip
wget http://download.jboss.org/wildfly/10.1.0.Final/wildfly-10.1.0.Final.zip

echo --------------- unzip wildfly-10.1.0.Final.zip -d /opt/
unzip wildfly-10.1.0.Final.zip -d /opt/
echo --------------- ln -s /opt/wildfly-10.1.0.Final /opt/wildfly
ln -s /opt/wildfly-10.1.0.Final /opt/wildfly

echo --------------- cp $HOME_TEMP/operations/wildfly/wildfly.conf /etc/default/wildfly
cp $HOME_TEMP/operations/wildfly/wildfly.conf /etc/default/wildfly

echo --------------- cp /opt/wildfly/docs/contrib/scripts/init.d/wildfly-init-debian.sh /etc/init.d/wildfly
cp /opt/wildfly/docs/contrib/scripts/init.d/wildfly-init-debian.sh /etc/init.d/wildfly
	
echo --------------- chown root:root /etc/init.d/wildfly
chown root:root /etc/init.d/wildfly
echo --------------- chmod +X /etc/init.d/wildfly
chmod +X /etc/init.d/wildfly

echo --------------- update-rc.d wildfly defaults	
update-rc.d wildfly defaults
echo --------------- update-rc.d wildfly enable
update-rc.d wildfly enable
	
echo --------------- mkdir -p /var/log/wildfly
mkdir -p /var/log/wildfly
	
useradd --system --shell /bin/false wildfly
useradd --system --shell /bin/false wildfly
		
echo --------------- /opt/wildfly/bin/add-user.sh admin tomas@256
/opt/wildfly/bin/add-user.sh admin tomas@256

echo --------------- cp $HOME_TEMP/operations/wildfly/standalone-full.xml /opt/wildfly/standalone/configuration/standalone-full.xml
cp $HOME_TEMP/operations/wildfly/standalone-full.xml /opt/wildfly/standalone/configuration/standalone-full.xml

echo --------------- service wildfly start
service wildfly start

echo ---------------
echo ---------------
echo --------------- installing MySQL JAVA Driver
echo --------------- cd /opt/wildfly/standalone/deployments
cd /opt/wildfly/standalone/deployments

echo --------------- wget http://central.maven.org/maven2/mysql/mysql-connector-java/5.1.27/mysql-connector-java-5.1.27.jar
wget http://central.maven.org/maven2/mysql/mysql-connector-java/5.1.27/mysql-connector-java-5.1.27.jar

echo --------------- chown -R wildfly:wildfly /opt/wildfly/standalone/deployments/
chown -R wildfly:wildfly /opt/wildfly/standalone/deployments/

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="data-source add --name=enterpriseDS --jndi-name=java:/jdbc/enterpriseDS --driver-name=mysql-connector-java-5.1.27.jar --connection-url=jdbc:mysql://dev.cdlcrgfnt1bu.us-east-1.rds.amazonaws.com:3306/ci_dev --user-name=awsuser --password=tomas128" 
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="data-source add --name=enterpriseDS --jndi-name=java:/jdbc/enterpriseDS --driver-name=mysql-connector-java-5.1.27.jar --connection-url=jdbc:mysql://dev.cdlcrgfnt1bu.us-east-1.rds.amazonaws.com:3306/ci_dev --user-name=awsuser --password=tomas128"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=undertow/configuration=handler/file=ImagesDirHandler/:add(cache-buffer-size=1024,cache-buffers=1024,directory-listing=true,follow-symlink=true,path=/var/www/html/wildfly/centralinmobiliaria-web/images)"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=undertow/configuration=handler/file=ImagesDirHandler/:add(cache-buffer-size=1024,cache-buffers=1024,directory-listing=true,follow-symlink=true,path=/var/www/html/wildfly/centralinmobiliaria-web/images)"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=undertow/server=default-server/host=default-host/location=\/centralinmobiliaria-web\/images\/:add(handler=ImagesDirHandler)" 
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=undertow/server=default-server/host=default-host/location=\/centralinmobiliaria-web\/images\/:add(handler=ImagesDirHandler)"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=naming/binding=java\:global\/fileUploadFolder:add(binding-type=simple, type=java.lang.String, value=/var/www/html/wildfly/centralinmobiliaria-web/images)" 
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=naming/binding=java\:global\/fileUploadFolder:add(binding-type=simple, type=java.lang.String, value=/var/www/html/wildfly/centralinmobiliaria-web/images)"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="jms-queue add --queue-address=eventsQueue --entries=java:/jms/queue/EventsQueue" 
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="jms-queue add --queue-address=eventsQueue --entries=java:/jms/queue/EventsQueue"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=co.hatit.enterprise:add"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=co.hatit.enterprise:add"
echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=co.hatit.enterprise:write-attribute(name=level,value=ALL)"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=co.hatit.enterprise:write-attribute(name=level,value=ALL)"
echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/periodic-rotating-file-handler=FILE:write-attribute(name=level,value=DEBUG)" 
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/periodic-rotating-file-handler=FILE:write-attribute(name=level,value=DEBUG)"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.drools:add"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.drools:add"
echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.drools:write-attribute(name=level,value=ALL)"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.drools:write-attribute(name=level,value=ALL)"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.kie:add"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.kie:add"
echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.kie:write-attribute(name=level,value=ALL)"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.kie:write-attribute(name=level,value=ALL)"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.jboss.security:add"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.jboss.security:add"
echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.jboss.security:write-attribute(name=level,value=TRACE)"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=logging/logger=org.jboss.security:write-attribute(name=level,value=TRACE)"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=security/security-domain=enterprise:add(cache-type=default)"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=security/security-domain=enterprise:add(cache-type=default)"

echo --------------- /opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=security/security-domain=enterprise/authentication=classic: \
    add( \
        login-modules=[{ \
            "code"=>"Client", \
            "flag"=>"required", \
            "module-options"=>[ \
                ("password-stacking"=>"true")] \
            }])"
/opt/wildfly/bin/jboss-cli.sh --connect --user=admin --password=tomas@256 --commands="/subsystem=security/security-domain=enterprise/authentication=classic: \
    add( \
        login-modules=[{ \
            "code"=>"Client", \
            "flag"=>"required", \
            "module-options"=>[ \
                ("password-stacking"=>"true")] \
            }])"



echo ---------------
echo ---------------
echo --------------- installing maven
echo --------------- apt-get install maven -y
apt-get install maven -y



echo ---------------
echo ---------------
echo --------------- deploying enterprise
echo --------------- cloning enterprise

echo --------------- cd $HOME_TEMP
cd $HOME_TEMP

echo --------------- git clone https://github.com/hatit/enterprise
git clone https://adrz1:tomas%40256@github.com/hatit/enterprise

echo --------------- cd $HOME_TEMP/enterprise 
cd $HOME_TEMP/enterprise

echo --------------- git branch testing
git checkout testing

echo --------------- mkdir /var/www
mkdir /var/www

echo --------------- mkdir /var/www/html
mkdir /var/www/html

echo --------------- mkdir /var/www/html/wildfly
mkdir /var/www/html/wildfly

echo --------------- mkdir /var/www/html/wildfly/centralinmobiliaria-web
mkdir /var/www/html/wildfly/centralinmobiliaria-web

echo --------------- mkdir /var/www/html/wildfly/centralinmobiliaria-web/images
mkdir /var/www/html/wildfly/centralinmobiliaria-web/images

echo --------------- sudo cp centralinmobiliaria-web/src/main/webapp/images/* /var/www/html/wildfly/centralinmobiliaria-web/images
cp centralinmobiliaria-web/src/main/webapp/images/* /var/www/html/wildfly/centralinmobiliaria-web/images

echo --------------- LC_ALL=en_US.UTF-8 mvn clean compile package -P co-centralinmobiliaria -Dmaven.test.skip=true 
LC_ALL=en_US.UTF-8 mvn clean compile package -P co-centralinmobiliaria -Dmaven.test.skip=true

echo --------------- cp centralinmobiliaria-web/target/centralinmobiliaria-web.war /opt/wildfly/standalone/deployments
cp centralinmobiliaria-web/target/centralinmobiliaria-web.war /opt/wildfly/standalone/deployments



echo ---------------
echo ---------------
echo --------------- starting github webhooks
echo --------------- mkdir /var/log/github
mkdir /var/log/github

echo --------------- java -cp $HOME_TEMP/operations/github/github.jar co.hatit.github.GithubWebhooks &
java -cp $HOME_TEMP/operations/github/github.jar co.hatit.github.GithubWebhooks > /var/log/github/webhook.log &



echo ---------------
echo ---------------
echo --------------- installing MEGA
echo --------------- apt-get install gcc build-essential libcurl4-openssl-dev libglib2.0-dev glib-networking libssl-dev -y
apt-get install gcc build-essential libcurl4-openssl-dev libglib2.0-dev glib-networking libssl-dev -y

echo --------------- cd $HOME_TEMP
cd $HOME_TEMP

echo --------------- wget http://megatools.megous.com/builds/megatools-1.9.95.tar.gz
wget http://megatools.megous.com/builds/megatools-1.9.95.tar.gz

echo --------------- tar -xvzf megatools-1.9.95.tar.gz
tar -xvzf megatools-1.9.95.tar.gz

echo --------------- cd megatools-1.9.95
cd megatools-1.9.95

echo --------------- ./configure --disable-shared
./configure --disable-shared

echo --------------- make install
make install

echo --------------- ./megadl 'https://mega.co.nz/#!L59ggbxb!ffZKQaxxQtOr3JLl066jRo_zLeIk8fnHIlp0tmuSgLU' --path=$HOME_TEMP
./megadl 'https://mega.co.nz/#!L59ggbxb!ffZKQaxxQtOr3JLl066jRo_zLeIk8fnHIlp0tmuSgLU' --path=$HOME_TEMP

echo --------------- cd $HOME_TEMP
cd $HOME_TEMP

echo --------------- apt-get install unrar
apt-get install unrar

echo --------------- unrar x -r imagenes-inmuebles.rar /var/www/html/wildfly/centralinmobiliaria-web/images/
unrar x -r imagenes-inmuebles.rar /var/www/html/wildfly/centralinmobiliaria-web/images/