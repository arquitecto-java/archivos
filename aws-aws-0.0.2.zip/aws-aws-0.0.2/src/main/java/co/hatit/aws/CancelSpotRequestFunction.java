package co.hatit.aws;

import java.util.List;

import com.amazonaws.services.ec2.model.CancelSpotInstanceRequestsRequest;
import com.amazonaws.services.ec2.model.CancelSpotInstanceRequestsResult;
import com.amazonaws.services.ec2.model.DescribeSpotInstanceRequestsResult;
import com.amazonaws.services.ec2.model.SpotInstanceRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesResult;

public class CancelSpotRequestFunction implements Function {

	@Override
	public String getName() {
		return "cancel";
	}
	
	@Override
	public String help() {
		return "Cancel all pending spot requests";
	}

	@Override
	public void run() throws Exception {
		DescribeSpotInstanceRequestsResult describeSpotInstanceRequestsResult = AWS.client.describeSpotInstanceRequests();
		
		CancelSpotInstanceRequestsRequest cancelSpotInstanceRequestsRequest = new CancelSpotInstanceRequestsRequest();
		List<SpotInstanceRequest> spotInstanceRequests = describeSpotInstanceRequestsResult.getSpotInstanceRequests();
		for (SpotInstanceRequest spotInstanceRequest : spotInstanceRequests) {
			if (spotInstanceRequest.getInstanceId() == null && "open".equals(spotInstanceRequest.getState())){//http://docs.aws.amazon.com/AWSEC2/latest/UserGuide/spot-bid-status.html
				cancelSpotInstanceRequestsRequest.withSpotInstanceRequestIds(spotInstanceRequest.getSpotInstanceRequestId());
			}
		}
		
		for (String spotInstanceRequestId : cancelSpotInstanceRequestsRequest.getSpotInstanceRequestIds()) {
			System.out.println("Canceling spotInstanceRequestId: " + spotInstanceRequestId);
		}
		CancelSpotInstanceRequestsResult cancelSpotInstanceRequestsResult = AWS.client.cancelSpotInstanceRequests(cancelSpotInstanceRequestsRequest);
	}

}
