package co.hatit.aws;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import com.amazonaws.services.ec2.model.Address;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesResult;

public class TerminateFunction implements Function {
	
	private static final String DOMAIN = "domain";
	
	private static Logger LOGGER = Logger.getLogger(RequestFunction.class.getName());

	@Override
	public String getName() {
		return "terminate";
	}
	
	@Override
	public String help() {
		return "Terminates an instance\n"
				+ "ie: terminate domain:hatit.co";
	}
	
	public List<String> validate(){
		ArrayList<String> errors = new ArrayList<String>();
		if (!AWS.settings.containsKey(DOMAIN)){
			errors.add(DOMAIN + " not defined, but required to excecute " + getName());
			LOGGER.severe(DOMAIN + " not defined, but required to excecute " + getName() + ".\nValid examples are hatit.co, ci.hatit.co, etc.");
		} 
		return errors;
	}

	@Override
	public void run() throws Exception {
		if (validate().isEmpty()){
			Address address = AWS.getElasticIp(AWS.settings.get(DOMAIN));
			
			TerminateInstancesRequest terminateInstancesRequest = new TerminateInstancesRequest(Arrays.asList(address.getInstanceId()));
			TerminateInstancesResult terminateInstancesResult = AWS.client.terminateInstances(terminateInstancesRequest);	
		} else {
			LOGGER.info(help());
		}
	}

}
