package co.hatit.aws;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Predicate;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.reflections.Reflections;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.Address;
import com.amazonaws.services.ec2.model.DescribeAddressesResult;
import com.amazonaws.services.ec2.model.TagDescription;

/**
 * Main entry point
 *
 */
public class AWS {
	private static Logger LOGGER = Logger.getLogger(AWS.class.getName());
	
	public static AmazonEC2 client;
	public static String myIp;
	
	/**
	 * current elastic IPs available or used
	 */
	public static List<Address> elasticIps;
	
	/**
	 * function to execute
	 */
	public static String function;
	public static HashMap<String, String> settings = new HashMap<String, String>();
	
	public static Address getElasticIp(String domain){
		TagDescription tag = client.describeTags().getTags().stream().filter(new Predicate<TagDescription>() {
			@Override
			public boolean test(TagDescription t) {
				return StringUtils.equals(t.getKey(), "domain") 
						&& StringUtils.equals(t.getValue(), domain)
						&& StringUtils.equals(t.getResourceType(), "elastic-ip");
			}
		}).findAny().orElse(null);
		if (tag != null){
			String resourceId = tag.getResourceId();
			return elasticIps.stream().filter(ip -> StringUtils.equals(resourceId, ip.getAllocationId())).findAny().orElse(null);
		}
		return null;
	}
	
	public static void main(String[] args) throws Exception {
		client = getAmazonEC2();
		
		DescribeAddressesResult describeAddressesResult = client.describeAddresses();
		elasticIps = describeAddressesResult.getAddresses();
		
		myIp = getMyIP();
		
		System.out.println("Hatit AWS CLI\n");
		System.out.println("available functions are:");
		Reflections reflections = new Reflections("co.hatit.aws");    
		Set<Class<? extends Function>> classes = reflections.getSubTypesOf(Function.class);
		ArrayList<Function> functions = new ArrayList<>();
		
		for (Class<? extends Function> clazz : classes) {
			Function f = clazz.newInstance();
			functions.add(f);
			System.out.println(f.getName());
		}
		
		System.out.println("\n>");
		
		Scanner sc = new Scanner(System.in);
		boolean exit = false;
		if (!exit){
			String in =  sc.nextLine();
			
			parseCmd(in.split(" "));
			
			for (Function f : functions) {
				if (f.getName().equals(function)){
					f.run();
				}
			}
		}

		System.out.println("finished");
	}

	public static void parseCmd(String[] args) {
		function = args[0];
		for (String arg : args) {
			if (!function.equals(arg)){
				String key = StringUtils.substringBefore(arg, ":");
				String value = "true";
				if (arg.contains(":")){
					value = StringUtils.substringAfter(arg, ":");
				}
				settings.put(key, value.replace("\"", ""));
			}
        }
	}
	
//	private static void createInstanceAlarm(String instanceId){
//		AmazonCloudWatch cw = AmazonCloudWatchClientBuilder.defaultClient();
//
//			Dimension dimension = new Dimension()
//			    .withName("InstanceId")
//			    .withValue(instanceId);
//
//			PutMetricAlarmRequest request = new PutMetricAlarmRequest()
//			    .withAlarmName("TerminatinCapacity-" + instanceId)
//			    .withComparisonOperator(
//			        ComparisonOperator.GreaterThanThreshold)
//			    .withEvaluationPeriods(1)
//			    .withMetricName("StatusCheckFailed")
//			    .withNamespace("AWS/EC2")
//			    .withPeriod(60)
//			    .withStatistic(Statistic.Average)
//			    .withThreshold(70.0)
//			    .withActionsEnabled(false)
//			    .withUnit(StandardUnit.Seconds)
//			    .withDimensions(dimension)
//			    .withac;
//
//			PutMetricAlarmResult response = cw.putMetricAlarm(request);
//			
//			request = new PutMetricAlarmRequest()
//				    .withAlarmName("StatusCheckFailed-" + instanceId)
//				    .withComparisonOperator(
//				        ComparisonOperator.GreaterThanThreshold)
//				    .withEvaluationPeriods(1)
//				    .withMetricName("StatusCheckFailed")
//				    .withNamespace("AWS/EC2")
//				    .withPeriod(60)
//				    .withStatistic(Statistic.Average)
//				    .withThreshold(70.0)
//				    .withActionsEnabled(false)
//				    .withUnit(StandardUnit.Seconds)
//				    .withDimensions(dimension);
//
//				PutMetricAlarmResult response = cw.putMetricAlarm(request);
//	}

	public static AmazonEC2 getAmazonEC2() {
//		System.setProperty("aws.accessKeyId", "AKIAIQ2VAB4EDRJVYKSA");
//		System.setProperty("aws.secretKey", "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");
		System.setProperty("aws.profile", "us-west-2");
//		AmazonEC2 client = AmazonEC2ClientBuilder.defaultClient();
		AmazonEC2 client = AmazonEC2ClientBuilder.standard()
				.withRegion("us-east-1")
				.withCredentials(new ProfileCredentialsProvider("hatit"))
				.build();
		
		return client;
	}

	public static String getMyIP() throws MalformedURLException, IOException {
		URL whatismyip = new URL("https://api.ipify.org");
		BufferedReader in = new BufferedReader(new InputStreamReader(whatismyip.openStream()));

		String ip = in.readLine(); // you get the IP as a String
		return ip;
	}
}
