package co.hatit.aws;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.amazonaws.services.ec2.model.Address;
import com.amazonaws.services.ec2.model.AuthorizeSecurityGroupIngressRequest;
import com.amazonaws.services.ec2.model.DescribeSecurityGroupsRequest;
import com.amazonaws.services.ec2.model.DescribeSecurityGroupsResult;
import com.amazonaws.services.ec2.model.IpPermission;
import com.amazonaws.services.ec2.model.IpRange;
import com.amazonaws.services.ec2.model.RevokeSecurityGroupIngressRequest;
import com.amazonaws.services.ec2.model.SecurityGroup;

public class RefreshAdminFunction implements Function {
	
	@Override
	public String getName() {
		return "refreshadmin";
	}

	@Override
	public String help() {
		return "Reresh security groups to allow access from local public IP";
	}

	@Override
	public void run() {
		IpRange myIpRange = new IpRange().withCidrIp(AWS.myIp + "/32");
		
		DescribeSecurityGroupsResult securityGroupsResult = AWS.client.describeSecurityGroups();
		for (SecurityGroup securityGroup : securityGroupsResult.getSecurityGroups()) {
			if (Arrays.asList("private-ssh", "management-wildfly").contains(securityGroup.getGroupName())){
				RevokeSecurityGroupIngressRequest revokeSecurityGroupIngressRequest = new RevokeSecurityGroupIngressRequest();
				revokeSecurityGroupIngressRequest.withGroupName(securityGroup.getGroupName()).withIpPermissions(securityGroup.getIpPermissions());
				try {
					AWS.client.revokeSecurityGroupIngress(revokeSecurityGroupIngressRequest);
				} catch (Exception e) { }
			}
		}

		AuthorizeSecurityGroupIngressRequest authorizeSecurityGroupIngressRequest = new AuthorizeSecurityGroupIngressRequest();
		IpPermission sshMyIpPermission = new IpPermission();
		sshMyIpPermission.withIpv4Ranges(myIpRange).withIpProtocol("tcp").withFromPort(22).withToPort(22);
		authorizeSecurityGroupIngressRequest.withGroupName("private-ssh").withIpPermissions(sshMyIpPermission);
		AWS.client.authorizeSecurityGroupIngress(authorizeSecurityGroupIngressRequest);

		authorizeSecurityGroupIngressRequest = new AuthorizeSecurityGroupIngressRequest();
		IpPermission wildflyMyIpPermission = new IpPermission();
		wildflyMyIpPermission.withIpv4Ranges(myIpRange).withIpProtocol("tcp").withFromPort(9990).withToPort(9990);
		authorizeSecurityGroupIngressRequest.withGroupName("management-wildfly").withIpPermissions(wildflyMyIpPermission);
		AWS.client.authorizeSecurityGroupIngress(authorizeSecurityGroupIngressRequest);
		
		DescribeSecurityGroupsRequest describeSecurityGroupsRequest = new DescribeSecurityGroupsRequest();
		describeSecurityGroupsRequest.withGroupNames("mysql");
		DescribeSecurityGroupsResult describeSecurityGroupsResult = AWS.client.describeSecurityGroups(describeSecurityGroupsRequest);
		SecurityGroup mysqlSecurityGroup = describeSecurityGroupsResult.getSecurityGroups().get(0);
		
		RevokeSecurityGroupIngressRequest revokeSecurityGroupIngressRequest = new RevokeSecurityGroupIngressRequest();
		revokeSecurityGroupIngressRequest.withGroupName("mysql");
		revokeSecurityGroupIngressRequest.withIpPermissions(mysqlSecurityGroup.getIpPermissions());
		AWS.client.revokeSecurityGroupIngress(revokeSecurityGroupIngressRequest);
		
		authorizeSecurityGroupIngressRequest = new AuthorizeSecurityGroupIngressRequest();
		IpPermission mysqlMyIpPermission = new IpPermission();
		mysqlMyIpPermission.withIpv4Ranges(myIpRange).withIpProtocol("tcp").withFromPort(3306).withToPort(3306);
		
		List<IpPermission> ipPermissions = new ArrayList<>();
		ipPermissions.add(mysqlMyIpPermission);
		
		for (Address addresss : AWS.elasticIps) {
			IpPermission mysqlElasticPublicIpPermission = new IpPermission();
			mysqlElasticPublicIpPermission.withIpv4Ranges(new IpRange().withCidrIp(addresss.getPublicIp() + "/32")).withIpProtocol("tcp").withFromPort(3306).withToPort(3306);
			ipPermissions.add(mysqlElasticPublicIpPermission);
			if (addresss.getPrivateIpAddress() != null){
				IpPermission mysqlElasticPrivateIpPermission = new IpPermission();
				mysqlElasticPrivateIpPermission.withIpv4Ranges(new IpRange().withCidrIp(addresss.getPrivateIpAddress() + "/32")).withIpProtocol("tcp").withFromPort(3306).withToPort(3306);
				ipPermissions.add(mysqlElasticPrivateIpPermission);
			}
		}
		
		authorizeSecurityGroupIngressRequest.withGroupName("mysql").withIpPermissions(ipPermissions);
		
		AWS.client.authorizeSecurityGroupIngress(authorizeSecurityGroupIngressRequest);
	}
	
}
