package co.hatit.aws;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.amazonaws.services.ec2.model.Address;
import com.amazonaws.services.ec2.model.SpotInstanceRequest;

public class RequestCIFunction extends RequestFunction {

	private static Logger LOGGER = Logger.getLogger(RequestCIFunction.class.getName());

	@Override
	public String getName() {
		return "requestci";
	}
	
	public List<String> validate(){
		AWS.settings.put(DOMAIN, "ci.hatit.co");
		return super.validate();
	}
	
	@Override
	public String help() {
		return "Request a new spot instance to be used in ci.hatit.co\n"
				+ "ie: requestci instanceType:m3.medium script:ci.hatit.co.sh";
	}
	
	public List<String> getSecurityGroups() {
		return Arrays.asList("private-ssh", "dev-http", "public-http", "management-wildfly");
	}
	
	@Override
	protected void waitSpotInstance(SpotInstanceRequest spotInstanceRequest) {
		super.waitSpotInstance(spotInstanceRequest);
		
		try {
			new RefreshAdminFunction().run();
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
		}
	}

}
