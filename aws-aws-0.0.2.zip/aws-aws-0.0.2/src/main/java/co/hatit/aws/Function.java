package co.hatit.aws;

public interface Function {
	String getName();
	
	String help();
	
	void run() throws Exception;
}
