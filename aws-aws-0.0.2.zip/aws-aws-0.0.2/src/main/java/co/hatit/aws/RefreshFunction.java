package co.hatit.aws;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import com.amazonaws.services.ec2.model.AuthorizeSecurityGroupIngressRequest;
import com.amazonaws.services.ec2.model.DescribeSecurityGroupsResult;
import com.amazonaws.services.ec2.model.IpPermission;
import com.amazonaws.services.ec2.model.IpRange;
import com.amazonaws.services.ec2.model.RevokeSecurityGroupIngressRequest;
import com.amazonaws.services.ec2.model.SecurityGroup;

public class RefreshFunction implements Function {
	
	private static final String GROUP = "group";
	
	private static Logger LOGGER = Logger.getLogger(RefreshFunction.class.getName());
	
	@Override
	public String getName() {
		return "refresh";
	}

	@Override
	public String help() {
		return "Request a security group IP permissions to from local public IP\n"
			+ "ie: refresh group:samir";
	}
	
	public List<String> validate(){
		ArrayList<String> errors = new ArrayList<String>();
		if (!AWS.settings.containsKey(GROUP)){
			errors.add(GROUP + " not defined, but required to excecute " + getName());
			LOGGER.severe(GROUP + " not defined, but required to excecute " + getName());
		} 
		return errors;
	}

	@Override
	public void run() {
		if (validate().isEmpty()){
			IpRange myIpRange = new IpRange().withCidrIp(AWS.myIp + "/32");
			
			DescribeSecurityGroupsResult securityGroupsResult = AWS.client.describeSecurityGroups();
			for (SecurityGroup securityGroup : securityGroupsResult.getSecurityGroups()) {
				if (AWS.settings.get(GROUP).equals(securityGroup.getGroupName())){
					List<IpPermission> ipPermissions = new ArrayList<>();
					for (IpPermission ipPermission : securityGroup.getIpPermissions()) {
						IpPermission newIpPermission = new IpPermission();
						newIpPermission.withIpv4Ranges(myIpRange).withIpProtocol(ipPermission.getIpProtocol()).withFromPort(ipPermission.getFromPort()).withToPort(ipPermission.getToPort());
						ipPermissions.add(newIpPermission);
					}
					
					if (securityGroup.getIpPermissions().get(0).getIpv4Ranges().contains(myIpRange)) continue;
					
					if (securityGroup.getIpPermissions().get(0).equals(ipPermissions.get(0))) continue;
					RevokeSecurityGroupIngressRequest revokeSecurityGroupIngressRequest = new RevokeSecurityGroupIngressRequest();
					revokeSecurityGroupIngressRequest.withGroupName(securityGroup.getGroupName()).withIpPermissions(securityGroup.getIpPermissions());
					try {
						AWS.client.revokeSecurityGroupIngress(revokeSecurityGroupIngressRequest);
					} catch (Exception e) { }
					AuthorizeSecurityGroupIngressRequest authorizeSecurityGroupIngressRequest = new AuthorizeSecurityGroupIngressRequest();
					
					authorizeSecurityGroupIngressRequest.withGroupName(securityGroup.getGroupName()).withIpPermissions(ipPermissions);
					AWS.client.authorizeSecurityGroupIngress(authorizeSecurityGroupIngressRequest);
				}
			}
		} else {
			LOGGER.info(help());
		}
	}
	
}
