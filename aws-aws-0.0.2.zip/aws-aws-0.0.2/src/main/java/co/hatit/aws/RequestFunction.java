package co.hatit.aws;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;

import com.amazonaws.services.ec2.model.Address;
import com.amazonaws.services.ec2.model.AssociateAddressRequest;
import com.amazonaws.services.ec2.model.BlockDeviceMapping;
import com.amazonaws.services.ec2.model.DescribeSpotInstanceRequestsRequest;
import com.amazonaws.services.ec2.model.DescribeSpotInstanceRequestsResult;
import com.amazonaws.services.ec2.model.EbsBlockDevice;
import com.amazonaws.services.ec2.model.LaunchSpecification;
import com.amazonaws.services.ec2.model.RequestSpotInstancesRequest;
import com.amazonaws.services.ec2.model.RequestSpotInstancesResult;
import com.amazonaws.services.ec2.model.SpotInstanceRequest;
import com.amazonaws.services.ec2.model.SpotInstanceType;
import com.amazonaws.services.ec2.model.SpotPlacement;

public class RequestFunction implements Function {

	protected static final String DOMAIN = "domain";
	private static final String INSTANCE_TYPE = "instanceType";
	private static final String MAX_SPOT_PRICE = "maxSpotPrice";
	private static final String DEFAULT_MAX_SPOT_PRICE = "0.07";
	private static final String SCRIPT = "script";
	
	private static Logger LOGGER = Logger.getLogger(RequestFunction.class.getName());

	@Override
	public String getName() {
		return "request";
	}
	
	@Override
	public String help() {
		return "Request a new spot instance\n"
				+ "ie: request domain:dali.hatit.co instanceType:m3.medium script:dali.hatit.co.sh";
	}
	
	public List<String> validate(){
		ArrayList<String> errors = new ArrayList<String>();
		if (!AWS.settings.containsKey(INSTANCE_TYPE)){
			errors.add(INSTANCE_TYPE + " not defined, but required to excecute " + getName());
			LOGGER.severe(INSTANCE_TYPE + " not defined, but required to excecute " + getName() + ".\nValid examples are m3.medium, etc.");
		} if (!AWS.settings.containsKey(MAX_SPOT_PRICE)){
			LOGGER.warning(MAX_SPOT_PRICE + " not defined, using default value (" + DEFAULT_MAX_SPOT_PRICE + ")");
			AWS.settings.put(MAX_SPOT_PRICE, DEFAULT_MAX_SPOT_PRICE);
		} if (!AWS.settings.containsKey(SCRIPT)){
			errors.add(SCRIPT + " not defined, but required to excecute " + getName());
			LOGGER.severe(SCRIPT + " not defined, but required to excecute " + getName());
		} if (!AWS.settings.containsKey(DOMAIN)){
			errors.add(DOMAIN + " not defined, but required to excecute " + getName());
			LOGGER.severe(DOMAIN + " not defined, but required to excecute " + getName() + ".\nValid examples are hatit.co, ci.hatit.co, etc.");
		} 
		return errors;
	}

	@Override
	public void run() throws Exception {
		if (validate().isEmpty()){
			
			RequestSpotInstancesRequest requestSpotInstancesRequest = new RequestSpotInstancesRequest();
			requestSpotInstancesRequest.setSpotPrice(AWS.settings.get(MAX_SPOT_PRICE));
			requestSpotInstancesRequest.setInstanceCount(Integer.valueOf(1));
			requestSpotInstancesRequest.setType(SpotInstanceType.OneTime);
			
			LaunchSpecification launchSpecification = new LaunchSpecification();
			launchSpecification.setImageId(getInstanceId());
			launchSpecification.setInstanceType(AWS.settings.get(INSTANCE_TYPE));
			launchSpecification.setKeyName("admin");
			SpotPlacement placement = new SpotPlacement(getPlacement());
			launchSpecification.setPlacement(placement);
			
			if (new File(AWS.settings.get(SCRIPT)).exists()){
				try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(AWS.settings.get(SCRIPT))))) {
					String encoded = getEncoded(r);
					launchSpecification.setUserData(encoded);
				} 
			} else {
				try (BufferedReader r = new BufferedReader(new InputStreamReader(AWS.class.getClassLoader().getResourceAsStream(AWS.settings.get(SCRIPT))))) {
					String encoded = getEncoded(r);
					launchSpecification.setUserData(encoded);
				} 
			}
			
			ArrayList<String> securityGroups = new ArrayList<String>();
			securityGroups.addAll(getSecurityGroups());
			launchSpecification.setSecurityGroups(securityGroups);
			
	//		// Create the block device mapping to describe the root partition.
			BlockDeviceMapping blockDeviceMapping = new BlockDeviceMapping();
			blockDeviceMapping.setDeviceName("/dev/sda1");
	
	//		// Set the delete on termination flag to false.
			EbsBlockDevice ebs = new EbsBlockDevice();
			ebs.setDeleteOnTermination(Boolean.TRUE);
			blockDeviceMapping.setEbs(ebs);
	
	//		// Add the block device mapping to the block list.
			ArrayList<BlockDeviceMapping> blockList = new ArrayList<BlockDeviceMapping>();
			blockList.add(blockDeviceMapping);
	
	//		// Set the block device mapping configuration in the launch specifications.
			launchSpecification.setBlockDeviceMappings(blockList);
			
			requestSpotInstancesRequest.setLaunchSpecification(launchSpecification);
			
			RequestSpotInstancesResult spotInstancesResult = AWS.client.requestSpotInstances(requestSpotInstancesRequest);
			if (spotInstancesResult.getSpotInstanceRequests().size() != 1) throw new IllegalStateException("no spot instance requested or more than one request active");
			waitSpotInstance(spotInstancesResult.getSpotInstanceRequests().get(0));
		} else {
			LOGGER.info(help());
		}
	}
	
	protected String getEncoded(BufferedReader r) throws IOException {
		StringBuffer userData = new StringBuffer("#!/bin/bash");
		userData.append("\n");
		for (String envVar : System.getenv().keySet()) {
			if (!StringUtils.startsWith(envVar, "aws_")) continue;
			userData.append("export " + StringUtils.substringAfter(envVar, "aws_") + "=\"" + System.getenv(envVar) + "\"").append("\n");
		};
		
		String line;
		while ((line = r.readLine()) != null){
			userData.append(line).append("\n");
		}
		String encoded = new String(Base64.encodeBase64(userData.toString().getBytes("UTF-8")), "UTF-8");
		
		return encoded;
	}
	
	public List<String> getSecurityGroups() {
		return Arrays.asList("private-ssh", "dev-http", "public-http", "samir", "andres");
	}

	public String getPlacement() {
		return "us-east-1d";
	}

	public String getInstanceId() {
		return "ami-f4cc1de2";
	}
	
	protected void waitSpotInstance(SpotInstanceRequest spotInstanceRequest) {
        boolean pending;
        String instanceId;
        do {
            DescribeSpotInstanceRequestsRequest describeRequest = new DescribeSpotInstanceRequestsRequest();
            describeRequest.setSpotInstanceRequestIds(Collections.singletonList(spotInstanceRequest.getSpotInstanceRequestId()));
            
            pending=false;

            try {
                DescribeSpotInstanceRequestsResult describeResult = AWS.client.describeSpotInstanceRequests(describeRequest);
                List<SpotInstanceRequest> describeResponses = describeResult.getSpotInstanceRequests();

                for (SpotInstanceRequest describeResponse : describeResponses) {
                    if (describeResponse.getState().equals("open")) {
                        pending = true;
                        break;
                    }
                    
                    AssociateAddressRequest associateAddressRequest = new AssociateAddressRequest();
                    associateAddressRequest.setInstanceId(describeResponse.getInstanceId());
                    associateAddressRequest.withPublicIp(getElasticIp().getPublicIp());
                    
                    AWS.client.associateAddress(associateAddressRequest);
                    System.out.println(getElasticIp() + " associated to instance created");
                    
//                    createInstanceAlarm(describeResponse.getInstanceId());
                }
            } catch (Exception e) {
                pending = true;
            }
            try {
                TimeUnit.SECONDS.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } while (pending);
    }

	public Address getElasticIp() {
		return AWS.getElasticIp(AWS.settings.get(DOMAIN));
	}

}
