request instanceType:m3.medium script:hatit.co-testing-development.sh

requestci instanceType:m3.medium script:ci.hatit.co.sh

to request blog dali saloom instance type:
request domain:dalissanchezpeluqueria.co maxSpotPrice:0.07 instanceType:m3.medium script:/Users/adrz1/repos/hatit/operations/aws/wordpress.sh
